import funcioness as fn 

trabajadores = ["Juan Pérez","María García","Carlos López","Ana Martínez","Pedro Rodríguez","Laura Hernández","Miguel Sánchez","Isabel Gómez","Francisco Díaz","Elena Fernández"]
sueldo_trabajador={}
while True:
    print("     MENU        ")
    print("*****************")
    print("0. Inicializar Sueldo")
    print("1. Asignar Sueldos")
    print("2. Clasificar Sueldo ")
    print("3. Ver estadisticas")
    print("4. Reportes de Sueldo")
    print("5. Salir")

    opcion = int(input("Ingrese una opcion: "))
    if opcion == 0 :
        sueldo_trabajador= {trabajador : 0 for trabajador in trabajadores}
        print("Haz inicializado correctamente")
    elif opcion == 1 :
        if not sueldo_trabajador:
            print("Debe inicializar los sueldos")
        else:
            sueldo_trabajador = fn.asignar_sueldo(trabajadores)
    elif opcion == 2 :
        if sueldo_trabajador:
            fn.clasificar_sueldo(sueldo_trabajador)
        else:
            print("Debe asignar sueldos")
    elif opcion == 3 :
        max_sueldo, min_sueldo, promedio_sueldo, media_geometrica = fn.ver_estadisticas(sueldo_trabajador)
        if max_sueldo is not None :
            print("Maximo sueldo es: ",max_sueldo)
            print("Minimo sueldo es: ",min_sueldo)
            print("Promedio sueldo es: ",promedio_sueldo)
            print("Media geometrica del sueldo es: ",media_geometrica)      
        else:
            print("Debe asignar sueldos")
    elif opcion == 4 :
        if sueldo_trabajador:
            fn.reporte_sueldo(sueldo_trabajador,)
        else:
            print("Debe asignar sueldos")
    elif opcion == 5 :
        print("Finalizando programa.....")
        print("Desarrollado por Camilo Calderon")
        print("Rut 20.502.456-5")
        break
    else:
        print("Debe seleccionar una opcion entre 0 y 5")
import random , csv 
import statistics

def asignar_sueldo(trabajadores) :
    sueldo_trabajador={}
    sueldo=random.randint(300000,2500000)
    for trabajador in trabajadores :
        sueldo_trabajador[trabajador]=sueldo
    print("Sueldo asignado")
    print(sueldo_trabajador)
    return sueldo_trabajador

def clasificar_sueldo(sueldo_trabajador) :
    menor_800_000={}
    entre_800_2_000={}
    mayor_2000={}

    for trabajador,sueldo in sueldo_trabajador.items() :
        if sueldo <800_000 :
            menor_800_000[trabajador]=sueldo
        elif sueldo <=2_000_000 :
            entre_800_2_000[trabajador]=sueldo
        else:
            mayor_2000[trabajador]=sueldo
        
    print("La cantidad de sueldo menor a $800.000 es un Total de : ",len(menor_800_000))
    for trabajador,sueldo in menor_800_000.items():
        print(trabajador,sueldo)
    print("La cantidad de sueldo entre $800.000 y $2.000.000 es un Total de : ",len(entre_800_2_000))
    for trabajador,sueldo in entre_800_2_000.items():
        print(trabajador,sueldo)
        
    print("La cantidad de sueldos mayor a $800.000 es un Total de : ",len(mayor_2000))
    for trabajador,sueldo in mayor_2000.items():
        print(trabajador,sueldo) 

def ver_estadisticas(sueldo_trabajador) :
    sueldos = list(sueldo_trabajador.values())
    if not sueldos :
        print("Debe asignar sueldos")  
        return None,None,None,None
    max_sueldo = max(sueldos)
    min_sueldo = min(sueldos)
    promedio_sueldo= sum(sueldos) / len(sueldos)
    media_geometrica = statistics.geometric_mean(sueldos)
    return max_sueldo,min_sueldo,promedio_sueldo,media_geometrica
def reporte_sueldo(sueldo_trabajador):
    for trabajador,sueldo in sueldo_trabajador.items() :
        descuentoSalud=sueldo*0.07
        DescuentoAFP=sueldo*0.12
        Sueldo_liquido=sueldo - descuentoSalud - DescuentoAFP
        print("Nombre empleado: ",trabajador)
        print("Sueldo Base: $",sueldo)
        print("Descuento Salud: $",descuentoSalud)
        print("Descuento AFP: $",DescuentoAFP)
        print("Sueldo Liquido: $",Sueldo_liquido)
  
    
    
    with open("reportes_sueldos.csv","w",newline="") as archivo:    
        escritor=csv.writer(archivo, delimiter=",")
    #Encabezados
        escritor.writerow(["Nombre de Empleado","Sueldo Base","Descuento Salud","Descuento AFP","Sueldo liquido"])
        for trabajador,sueldo in sueldo_trabajador.items():
            escritor.writerow([trabajador,sueldo,descuentoSalud,DescuentoAFP,Sueldo_liquido])
    print("Los reportes han sido creado con exito")